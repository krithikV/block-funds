# importing Flask and other modules
from flask import Flask, request, render_template, session
import smart_call
import cpf
# Flask constructor
app = Flask(__name__) 
app.secret_key = 'F8f97cD1D84098C0fb15eae365ea96eacBAe90fc'

# A decorator used to tell the application
# which URL is associated function
def chunks(lst, n):
	a = []
	for i in range(0, len(lst), n):
		a.append(lst[i:i + n])
	return a
	

@app.route('/')
def login_render():
	return render_template("login.html")

@app.route('/portfolio', methods =["GET", "POST"])
def portfolio():
	if request.method == "POST":
		adr = request.form.get("adr")
		pvt = request.form.get("pvt")
		if smart_call.is_participant(adr) == False:
			smart_call.register_participant(adr,pvt) 
		pf_total = smart_call.balances(adr)
		asset_total = smart_call.get_total_asset_value(adr)
		session['adr'] = adr
		session['pvt'] = pvt
	return render_template("dashboard.html",pf_total = pf_total,asset_total = asset_total)

@app.route('/managepf',methods=['GET','POST'])
def manage_pf():
	pf_total = smart_call.balances(session['adr'])
	history = chunks(list(smart_call.get_deposit_history(session['adr'])),2)
	if request.method == "POST":
		amt = int(request.form.get('amt'))
		age = int(request.form.get('age'))
		smart_call.deposit(amt,int(cpf.calculate_pf_contribution(age,amt)),session['adr'],session['pvt'])
	return render_template("pf.html",pf_total = pf_total,len = len(history[0]),data = history[0])

@app.route('/manageassets',methods=['GET','POST'])
def manage_asset():
	if request.method == "POST":
		if request.form.get('sender'):
			smart_call.transfer_asset(request.form.get('sender'),int(request.form.get('index')),session['adr'],session['pvt'])
		if request.form.get('asset'):
			print(request.form.get('asset'))
			smart_call.add_asset(int(request.form.get('asset')),request.form.get('title'),session['adr'],session['pvt'])

	asset_total = smart_call.get_total_asset_value(session['adr'])
	if len(smart_call.get_assets(session['adr'])) > 0:
		history = chunks(list(smart_call.get_assets(session['adr'])),2)
		print(history[0])
	else:
		history = [[]]
	return render_template("asset.html",asset_total = asset_total,len = len(history[0]),data = history[0])



if __name__=='__main__':
    app.run()
